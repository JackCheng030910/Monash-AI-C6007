/*****PLEASE ENTER YOUR DETAILS BELOW*****/
--T2-brm-insert.sql

--Student ID:
--Student Name:

/*
Indicate if AI was used (Yes/No):

If AI was used:
I used <<specify the GenAI tool here>>
I used these prompts:
*/

--------------------------------------
--INSERT INTO employee
--------------------------------------


--------------------------------------
--INSERT INTO quote
--------------------------------------


--------------------------------------
--INSERT INTO job
--------------------------------------


